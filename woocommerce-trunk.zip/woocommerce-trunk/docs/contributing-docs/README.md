---
category_title: Contribute to Docs 
category_slug: contributing-docs
post_title: Contribute to Docs
---

Just like WooCommerce itself, our developer docs are open source and editable by the community. This category outlines guidance and best practices to follow when contributing documentation.
 