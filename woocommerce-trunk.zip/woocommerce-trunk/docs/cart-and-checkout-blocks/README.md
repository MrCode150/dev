---
category_title: Cart and Checkout Blocks 
category_slug: cart-and-checkout-blocks
post_title: Cart and Checkout blocks - Extensibility
---
