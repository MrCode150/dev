---
category_title: Theme Development 
category_slug: theme-development
post_title: Theme Development
---

Learn to design and integrate custom themes in WooCommerce, focusing on responsive design and ecommerce optimization.

This document was created for use when developing classic themes. Check this other document for [block theme development](../../plugins/woocommerce-blocks/docs/designers/theming/README.md).
