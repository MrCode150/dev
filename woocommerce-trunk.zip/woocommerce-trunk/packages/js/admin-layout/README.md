# Admin Layout

A collection of WooCommerce Admin layout components and utilities.

## Installation

Install the module

```bash
pnpm install @woocommerce/product-editor --save
```
