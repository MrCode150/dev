# Artificial Intelligence tools

A collection of WooCommerce tools and utilities to implement ai features.

## Installation

Install the module

```bash
pnpm install @woocommerce/ai --save
```
