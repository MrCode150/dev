# Changelog

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
