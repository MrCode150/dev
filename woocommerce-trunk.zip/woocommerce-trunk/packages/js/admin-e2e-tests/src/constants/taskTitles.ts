export const TaskTitles = {
	storeDetails: 'Store details',
	addPayments: 'Get paid',
	wooPayments: 'Get paid with WooPayments',
	addProducts: 'Add your products',
	taxSetup: 'Collect sales tax',
	setUpShippingCosts: 'Get your products shipped',
	personalizeStore: 'Personalize my store',
};
