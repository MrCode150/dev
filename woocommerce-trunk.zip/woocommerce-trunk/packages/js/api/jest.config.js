module.exports = {
	preset: 'ts-jest',
	verbose: true,
	rootDir: './',
	roots: [
		'<rootDir>/src',
	],
	testEnvironment: 'node',
};
