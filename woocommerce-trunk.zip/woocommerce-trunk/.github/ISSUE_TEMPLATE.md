<!-- This form is for other issue types specific to the WooCommerce plugin. This is not a support portal. -->

**Prerequisites (mark completed items with an [x]):**
- [ ] I have checked that my issue type is not listed here https://github.com/woocommerce/woocommerce/issues/new/choose
- [ ] My issue is not a security issue, support request, bug report, enhancement or feature request (Please use the link above if it is).

**Issue Description:**
