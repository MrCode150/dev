# GitHub Action: Setup WooCommerce Monorepo

This action will prime the plugins, packages, and tools in the monorepo for other workflows. This includes support for installing dependencies, building projects, and caching the output of both.

## Usage

See [`action.yml`](action.yml) for information about all of the inputs the action supports.
