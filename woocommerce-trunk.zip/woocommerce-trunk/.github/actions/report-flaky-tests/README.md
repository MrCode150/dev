# Report Flaky Tests

A GitHub action to report flaky E2E tests to GitHub issues.

**This package is still experimental and breaking changes could be introduced in future minor versions (`v0.x`). Use it at your own risks.**

<br/><br/><p align="center"><img src="https://s.w.org/style/images/codeispoetry.png?1" alt="Code is Poetry." /></p>
